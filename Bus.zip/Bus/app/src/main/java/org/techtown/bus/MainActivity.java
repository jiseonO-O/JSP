package org.techtown.bus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {
    Handler mHandler = null;
    double rslt;
    String result;
    private GoogleMap googleMap;


    EditText edit, edit2;
    TextView text;
    String lat;
    String longg;
    static TextView textView;

    double na;
    double latitude;
    double longitude;
    String busid, busline;
    String data4;
    private static final int GPS_ENABLE_REQUEST_CODE = 2001;
    private static final int PERMISSIONS_REQUEST_CODE = 100;

    String[] REQUIRED_PERMISSIONS = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
    final String key = "%2B6wk99uklzLUFFo6Ex96lJwk2pWLLQZ0W7hjlxZhwu5zw1WFSoa1kFZgX92Dyncv3dO6OXuUcANOEybG0S8lcA%3D%3D";

    String bsname = "";
    String data;
    String data2;
    String data3;

    double mLatitude;
    double mLongitude;

    String bstid = "";
    String bstline = "";
    String bsa = "";

    double dex;
    double dey;

    String[] num2 = new String[2];
    String[] num = new String[2];

    int count = 0;
    int count2 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit2 = (EditText) findViewById(R.id.edit2);
        edit = (EditText) findViewById(R.id.edit);
        text = (TextView) findViewById(R.id.text);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        Button button = findViewById(R.id.button);
        button2.setVisibility(View.INVISIBLE);
        button3.setVisibility(View.INVISIBLE);
    }

    String getXmlData() {
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        StringBuffer buffer = new StringBuffer();
        String str = edit.getText().toString(); //EditText에 작성된 Text 얻기
        String str2 = edit2.getText().toString();
        String location2 = str2;
        String location = str;
        if (location.contains("-")) {
            location = location.replace("-", "");
            location = "5200" + location + "00";
        } else if (Integer.parseInt(location) > 1000) {
            location = "520" + location + "000";
        } else if (Integer.parseInt(location) > 100) {
            location = "5200" + location + "000";
        } else if (Integer.parseInt(location) < 100) {
            location = "52000" + location + "000";
        } /* 116~124 줄 까지는 데이터를 형식에 맞게 바꿔주는 코드 */
        try {
        String queryUrl = "http://apis.data.go.kr/6260000/BusanBIMS/busInfoByRouteId?lineid=" + location + "&serviceKey=" + key;
            URL url = new URL(queryUrl); //문자열로 된 요청 url을 URL 객체로 생성.
            InputStream is = url.openStream(); //url 위치로 입력스트림 연결
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new InputStreamReader(is, "UTF-8")); //inputstream 으로부터 xml 입력받기
            String tag;
            xpp.next();
            int eventType = xpp.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        buffer.append("파싱 시작...\n\n"); /* 버퍼 = 변수 안에 값 넣기 */
                        break;
                    case XmlPullParser.START_TAG: /* 값 저장 시작 */
                        tag = xpp.getName();//태그 이름 얻어오기
                        if (tag.equals("item")) ;
                        xpp.next();
                        if (tag.equals("bstopnm")) { /* bstopnm  값을 bsname에 저장*/
                            bsname = xpp.getText();
                            buffer.append("정류소 아이디 :");
                            buffer.append(xpp.getText()); /*buffer.append 에 저장 */
                            buffer.append("\n");
                            xpp.next();
                        } else if (tag.equals("arsno")) {
                            if (location2.equals(bsname)) {
                                num[count] = xpp.getText();
                                count++;
                                bstid = xpp.getText();
                                buffer.append("정류소번호 :");
                            }
                            buffer.append("\n"); //줄바꿈 문자 추가
                            xpp.next();
                        } else if (tag.equals("direction")) {
                            buffer.append("방향:");
                            bsa = xpp.getText();
                            buffer.append(xpp.getText()); /* 2번 뺴고 상행선이라 ..*/
                            if (xpp.getText().equals("1") || xpp.getText().equals("3") || xpp.getText().equals("0")) {
                                buffer.append("상행선");
                            } else if (xpp.getText().equals("2")) {
                                buffer.append("하행선");
                            } else {
                                buffer.append("하행선");
                            }
                            buffer.append("\n");
                            xpp.next();
                        }
                        break;
                    case XmlPullParser.TEXT:
                        break;
                    case XmlPullParser.END_TAG:
                        tag = xpp.getName(); //태그 이름 얻어오기
                        if (tag.equals("item")) {
                            buffer.append("\n");  //첫번째 검색결과 종료..줄바꿈
                        }
                        break;
                }
                eventType = xpp.next();
            }
        } catch (Exception e) {
        }
        return buffer.toString(); //StringBuffer 문자열 객체 반환
    }

    String getXmlData2() {
        String str = edit.getText().toString(); //EditText에 작성된 Text 얻기
        String str2 = edit2.getText().toString();
        String location2 = str2;
        String location = str;
        if (location.contains("-")) {
            location = location.replace("-", "");
            location = "5200" + location + "00";
        } else if (Integer.parseInt(location) > 1000) {
            location = "520" + location + "000";
        } else if (Integer.parseInt(location) > 100) {
            location = "5200" + location + "000";
        } else if (Integer.parseInt(location) < 100) {
            location = "52000" + location + "000";
        }
        StringBuffer buffer = new StringBuffer();
        /* 위 queryUrl 과 다른 이유는 리스폰스되는 값이 달라서 */
        String queryUrl = "http://apis.data.go.kr/6260000/BusanBIMS/busStopList?bstopnm=" + location2 + "&arsno=" + bstid + "&pageNo=1&numOfRows=10&serviceKey=" + key;
        try {
            URL url = new URL(queryUrl); //문자열로 된 요청 url을 URL 객체로 생성.
            InputStream is = url.openStream(); //url 위치로 입력스트림 연결
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new InputStreamReader(is, "UTF-8")); //inputstream 으로부터 xml 입력받기
            String tag;
            xpp.next();
            int eventType = xpp.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        buffer.append("파싱 시작...\n\n");
                        break;

                    case XmlPullParser.START_TAG:
                        tag = xpp.getName();//태그 이름 얻어오기
                        if (tag.equals("item")) ;
                        xpp.next();

                        if (tag.equals("bstopid")) {
                            bstline = xpp.getText();
                            bsname = xpp.getText();
                            xpp.next();
                        }
                        break;
                    case XmlPullParser.TEXT:
                        break;
                    case XmlPullParser.END_TAG:
                        tag = xpp.getName(); //태그 이름 얻어오기
                        if (tag.equals("item")) buffer.append("\n");  //첫번째 검색결과 종료..줄바꿈
                        break;
                }

                eventType = xpp.next();
            }
        } catch (Exception e) {

        }

        return buffer.toString(); //StringBuffer 문자열 객체 반환
    }

    String getXmlData3() {
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        String str = edit.getText().toString(); //EditText에 작성된 Text 얻기
        String str2 = edit2.getText().toString();
        button2.setVisibility(View.INVISIBLE);
        button3.setVisibility(View.INVISIBLE);
        String location2 = str2;
        String location = str;
        if (location.contains("-")) {
            location = location.replace("-", "");
            location = "5200" + location + "00";
        } else if (Integer.parseInt(location) > 1000) {
            location = "520" + location + "000";
        } else if (Integer.parseInt(location) > 100) {
            location = "5200" + location + "000";
        } else if (Integer.parseInt(location) < 100) {
            location = "52000" + location + "000";
        }
        StringBuffer buffer = new StringBuffer();
        /* 위 queryUrl 과 다른 이유는 리스폰스되는 값이 달라서  */
        /*3중 xml 파싱*/
        String queryUrl = "http://apis.data.go.kr/6260000/BusanBIMS/busStopArrByBstopidLineid?bstopid=" + bstline + "&lineid=" + location + "&serviceKey=" + key;
        try {
            URL url = new URL(queryUrl); //문자열로 된 요청 url을 URL 객체로 생성.
            InputStream is = url.openStream(); //url 위치로 입력스트림 연결

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new InputStreamReader(is, "UTF-8")); //inputstream 으로부터 xml 입력받기

            String tag;

            xpp.next();
            int eventType = xpp.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        buffer.append("파싱 시작...\n\n");
                        break;

                    case XmlPullParser.START_TAG:
                        tag = xpp.getName();//태그 이름 얻어오기
                        if (tag.equals("item")) ;
                        xpp.next();

                        if (tag.equals("nodenm")) {
                            bsname = xpp.getText();

                            xpp.next();
                        } else if (tag.equals("lineno")) {
                            bsname = xpp.getText();
                            busline = xpp.getText();

                            xpp.next();
                        }
                        if (tag.equals("min1")) {
                            bsname = xpp.getText();
                            buffer.append("1번째 버스 :");
                            buffer.append(xpp.getText() + "분");
                            buffer.append("\n");
                            xpp.next();
                        } else if (tag.equals("station1")) {
                            bsname = xpp.getText();
                            buffer.append("1번째 버스 남은 정류장 :");
                            buffer.append(xpp.getText() + "정류장");
                            buffer.append("\n");
                            xpp.next();
                        } else if (tag.equals("lowplate1")) {
                            bsname = xpp.getText();
                            buffer.append("버스타입:");
                            String ty1;
                            ty1=xpp.getText();
                            if(ty1.equals("1"))
                            {
                                buffer.append("저상");
                            }else{
                                buffer.append("일반");
                            }

                            buffer.append("\n");
                            xpp.next();
                        } else if (tag.equals("min2")) {
                            bstid = xpp.getText();
                            buffer.append("2번째 버스");
                            buffer.append(xpp.getText() + "분");//addr 요소의 Text 읽어와서 문자열버퍼에 추가
                            buffer.append("\n"); //줄바꿈 문자 추가
                            xpp.next();
                        }
                        else if (tag.equals("gpsx")) {
                            dex = Double.parseDouble(xpp.getText());

                            xpp.next();
                        } else if (tag.equals("gpsy")) {
                            dey = Double.parseDouble(xpp.getText());

                            xpp.next();
                        }
                        else if (tag.equals("station2")) {
                            bsname = xpp.getText();
                            buffer.append("2번째 버스 남은 정류장 :");
                            buffer.append(xpp.getText() + "정류장");
                            buffer.append("\n");
                            xpp.next();
                        } else if (tag.equals("lowplate2")) {
                            bsname = xpp.getText();
                            buffer.append("버스타입:");
                            String ty2;
                            ty2=xpp.getText();
                            if(ty2.equals("1"))
                            {
                                buffer.append("저상");
                            }else{
                                buffer.append("일반");
                            }

                            buffer.append("\n");
                            xpp.next();
                        } else if (tag.equals("carno1")) {
                            bsname = xpp.getText();
                            busid = xpp.getText();

                            xpp.next();
                        }
                        break;
                    case XmlPullParser.TEXT:
                        break;
                    case XmlPullParser.END_TAG:
                        tag = xpp.getName(); //태그 이름 얻어오기
                        if (tag.equals("item")) buffer.append("\n");  //첫번째 검색결과 종료..줄바꿈
                        break;
                }
                eventType = xpp.next();
            }
        } catch (Exception e) {
        }

        return buffer.toString(); //StringBuffer 문자열 객체 반환
    }

    public void mOnClick(View v) {
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);


        switch (v.getId()) {
            case R.id.button:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        data = getXmlData();
                        data2 = getXmlData2();
                        data3 = getXmlData3();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                text.setText(data3);

                                SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
                                mapFragment.getMapAsync(MainActivity.this);
                                if (count == 2) {
                                    button2.setVisibility(View.VISIBLE);
                                    button3.setVisibility(View.VISIBLE);
                                } else {
                                    button2.setVisibility(View.INVISIBLE);
                                    button3.setVisibility(View.INVISIBLE);
                                }
                            }

                        });

                    }
                })
                        .start();
                break;
        }
    }

    public void b1(View v) {
        switch (v.getId()) {
            case R.id.button2:
                bstid = num[0];
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        data = getXmlData();
                        data2 = getXmlData2();
                        data3 = getXmlData3();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                text.setText(data3);
                                SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
                                mapFragment.getMapAsync(MainActivity.this);
                            }
                        });
                    }
                }).start();
                break;
        }

    }

    public void b2(View v) {
        switch (v.getId()) {
            case R.id.button3:
                bstid = num[1];
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        data = getXmlData();
                        data2 = getXmlData2();
                        data3 = getXmlData3();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                text.setText(data3);
                                SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
                                mapFragment.getMapAsync(MainActivity.this);
                            }
                        });
                    }
                }).start();
                break;
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.googleMap = googleMap;


        LatLng location = new LatLng(dey, dex); /*좌표 y,x 를 찍을거다*/
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(location)); /*현위치*/
        googleMap.moveCamera(CameraUpdateFactory.zoomTo(18)); /* 줌 18배*/
        MarkerOptions markerOptions = new MarkerOptions().position(location);
        googleMap.addMarker(markerOptions);

/*
        CircleOptions circle1KM = new CircleOptions().center(location)
                .radius(20)
                .strokeWidth(0f)
                .fillColor(Color.parseColor("#E6FFFF"));
        this.googleMap.addCircle(circle1KM);
*/


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            googleMap.setMyLocationEnabled(true);

        } else {
            checkLocationPermissionWithRationale();
        }
    }

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99; /*위치 권한*/

    private void checkLocationPermissionWithRationale() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                new AlertDialog.Builder(this)
                        .setTitle("위치정보")
                        .setMessage("이 앱을 사용하기 위해서는 위치정보에 접근이 필요합니다.위치정보 접근을 허용하여 주세요.")
                        .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        }).create().show();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_LOCATION);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        googleMap.setMyLocationEnabled(true);
                    }
                } else {
                    Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    public String getCurrentAddress(double latitude, double longitude) {
        //지오코더... GPS를 주소로 변환
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses;
        try {
            addresses = geocoder.getFromLocation(
                    latitude,
                    longitude,
                    7);
        } catch (IOException ioException) {
            //네트워크 문제
            Toast.makeText(this, "지오코더 서비스 사용불가", Toast.LENGTH_LONG).show();
            return "지오코더 서비스 사용불가";
        } catch (IllegalArgumentException illegalArgumentException) {
            Toast.makeText(this, "잘못된 GPS 좌표", Toast.LENGTH_LONG).show();
            return "잘못된 GPS 좌표";
        }
        Address address = addresses.get(0);
        return address.getAddressLine(0).toString() + "\n";
    }

    public boolean checkLocationServicesStatus() {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }
}